Tryck V f�r att equippa vapen
Tryck X f�r att skada

Klicka p� sk�rmen f�r att g�

Kan prata med den rosa gubben och skylten

Kan skada den bl�a gubben

Man ska kunna g� ungef�r som i en 3rd person shooter men hann inte klart med det systemet
H�ller �ven p� att implementerar skjutvapen och ett questing system